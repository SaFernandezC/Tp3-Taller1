#ifndef _LISTENER_H
#define _LISTENER_H

#include "Thread.h"
#include <atomic>
#include <string>
#include "../common_src/Socket.h"
#include "Organizador.h"

//Todos los metodos lanzan las excepciones correspondientes
//en caso de error

class Listener: public Thread{
  private:
    Socket accepter;
    std::atomic<bool> seguirAceptando;
    Organizador organizador;

  public:
    explicit Listener(const std::string& port);

    virtual void run() override;

    void stop();

    ~Listener();
};

#endif
