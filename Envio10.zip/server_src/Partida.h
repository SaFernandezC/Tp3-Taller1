#ifndef _PARTIDA_H
#define _PARTIDA_H

#include <string>
#include <mutex>
#include <condition_variable>

#include "Tateti.h"
#include "ExcepcionServer.h"

//Todos los metodos lanzan las excepciones correspondientes
//en caso de error

class Partida{
  private:
    std::mutex mtx;
    std::condition_variable cambioTurno;
    char turno;
    bool jugando;
    Tateti juego;

  public:
    Partida();

    bool enJuego();

    std::string obtenerTablero(const char& tipoJugador);

    void jugar(const char& tipo_jugador, char col, char fil);

    ~Partida();

  private:
    void cambiarTurno(const char& tipo_jugador);
};

#endif
